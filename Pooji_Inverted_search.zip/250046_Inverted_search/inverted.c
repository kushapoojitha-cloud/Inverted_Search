#include "inverted.h"

/* Function to validate input files passed through command line */
void validate_files(char *argv[], F_node **head)
{
    int i = 1;      // Start from first filename
    char *res;      // Pointer to store extension result
    printf(PURPLE "--------------------------------------------------------------------------------\n"RESET);
    while (argv[i]) // Traverse through all command line arguments
    {
        res = strstr(argv[i], "."); // Check for file extension
        if (res)                    // If extension exists
        {
            if (strcmp(res, ".txt") == 0) // Check whether file is a .txt file
            {
                FILE *fptr = fopen(argv[i], "r"); // Open file in read mode
                if (fptr)                         // Check if file exists
                {
                    fseek(fptr, 0, SEEK_END);               // Move pointer to end of file
                    unsigned long int f_tell = ftell(fptr); // Get file size
                    rewind(fptr);                           // Reset pointer to beginning
                    if (f_tell)                             // Check if file is not empty
                    {
                        if (check_duplicates(*head, argv[i]) == FAILURE) // Check if file name is already present in list
                        {
                            if (insert_last(head, argv[i]) == SUCCESS) // Insert file name at end of linked list
                                printf(GREEN"INFO : Successful : Inserting file name %s into file linked list\n\n"RESET, argv[i]);
                        }
                        else
                            printf(YELLOW"INFO : %s => This file is repeated, so it will not store into the sll\n\n"RESET, argv[i]);
                    }
                    else
                        printf(YELLOW"INFO : %s => This file is empty\n\n"RESET, argv[i]);
                    fclose(fptr);       // Close the file
                }
                else
                    printf(YELLOW"INFO : %s => This file does not exist in the current directory\n\n"RESET, argv[i]);
            }
            else
                printf(RED"INFO : %s => This file is not .txt\n\n"RESET, argv[i]);
        }
        else
            printf(RED"INFO : %s => This file has without extension\n\n"RESET, argv[i]);
        i++; // Move to next argument
    }
    printf(PURPLE "--------------------------------------------------------------------------------\n"RESET);
}
int check_duplicates(F_node *head, char *f_name) /* Function to check whether filename is already present */
{
    while (head) // Traverse the file linked list
    {
        if (strcmp(head->f_name, f_name) == 0) // Compare stored filename with given filename
            return SUCCESS;                    // Duplicate found
        head = head->link;                     // Move to next node
    }
    return FAILURE; // No duplicate found
}
/* Function to insert filename at the end of file linked list */
int insert_last(F_node **head, char *f_name)
{
    F_node *new_node = malloc(sizeof(F_node)); // Allocate memory for new node
    if (new_node == NULL)                      // Check for memory allocation failure
        return FAILURE;
    strcpy(new_node->f_name, f_name); // Store filename
    new_node->link = NULL;            // Initialize link
    if (*head == NULL)                // If list is empty
        *head = new_node;
    else
    {
        F_node *temp = *head;
        while (temp->link != NULL) // Traverse till last node
        {
            temp = temp->link;
        }
        temp->link = new_node; // Link new node at the end
    }
    return SUCCESS;
}
/* Function to print all filenames in the linked list */
int print_filenames(F_node *head)
{
    if (head == NULL) // Check if list is empty
        return FAILURE;
    printf(BLUE"\n>>> Valid input files selected for inverted index <<\n\n"RESET);
    while (head) // Traverse and print filenames
    {
        printf(CYAN"%s -> ", head->f_name);
        head = head->link;
    }
    printf("NULL\n"RESET); // End of list
    return SUCCESS;
}
/* Function to calculate hash table index for a word */
int get_index(char *word)
{
    if (word[0] >= 'A' && word[0] <= 'Z')      // If word starts with uppercase letter
        return word[0] - 'A';                  // A to Z will return 0 to 25
    else if (word[0] >= 'a' && word[0] <= 'z') // If word starts with lowercase letter
        return word[0] - 'a';                  // a to z- will return 0 to 25
    else                                       // If word starts with non-alphabet character
        return 26;                             // Special index for symbols/numbers
}